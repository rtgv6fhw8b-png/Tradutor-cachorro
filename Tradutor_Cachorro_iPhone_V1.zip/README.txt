TRADUTOR DE CACHORRO — iPHONE

Abra o index.html em um serviço que hospede páginas (por exemplo, GitHub Pages,
Netlify ou Vercel) e depois abra o endereço no Safari.

IMPORTANTE:
- O Safari exige HTTPS para permitir o microfone em uma página hospedada.
- A V1 é experimental e não representa uma tradução comprovada da linguagem canina.
- Para colocar como ícone na Tela de Início: Safari > Compartilhar > Adicionar à Tela de Início.
